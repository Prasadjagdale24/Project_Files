package com.madhura.cas.utilities;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;

import com.madhura.cas.MainApplication;
import com.madhura.cas.logger.Category;
import com.madhura.cas.logger.RDDLog;

public class CustomAudioPlayer {
	private static CustomAudioPlayer _player;
	private MediaPlayer _mediaPlayer = null;
	private AudioManager _audioManager;
	private int _previsousVolume;

	private final int AUDIO_STREAM_TYPE = AudioManager.STREAM_ALARM;

	private CustomAudioPlayer() {
		_audioManager = (AudioManager) MainApplication.appContext.getSystemService(Context.AUDIO_SERVICE);
	}

	public static CustomAudioPlayer getInstance() {
		if (_player == null) {
			_player = new CustomAudioPlayer();
		}
		return _player;
	}

	public void play(String mediaFilePath, boolean fromAssets) {
		if (!isPlaying()) {
			if (_mediaPlayer == null) {
				_mediaPlayer = new MediaPlayer();
			}
			_setVolumeToMax();

			try {
				if (fromAssets) {
					AssetFileDescriptor descriptor = MainApplication.appContext.getAssets().openFd(mediaFilePath);
					_mediaPlayer.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
					descriptor.close();
				}

				_mediaPlayer.prepare();
				_mediaPlayer.setLooping(true);
				_mediaPlayer.start();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	public void stop() {
		if (isPlaying()) {
			_resetVolume();
			if (_mediaPlayer != null) {
				_mediaPlayer.stop();
				_mediaPlayer.reset();
			}
		}
	}

	public boolean isPlaying() {
		try {
			if (_mediaPlayer != null && _mediaPlayer.isPlaying()) {
				return true;
			}
		} catch (Exception e) {
			RDDLog.error(Category.CAT_OTHER, "CustomAudioPlayer: isPlaying: Exception->" + e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

	private void _setVolumeToMax() {
		try {
			if (_mediaPlayer != null) {
				_mediaPlayer.setAudioStreamType(AUDIO_STREAM_TYPE);
			}

			_previsousVolume = _audioManager.getStreamVolume(AUDIO_STREAM_TYPE);
			int maxSteamVolume = _audioManager.getStreamMaxVolume(AUDIO_STREAM_TYPE);
			_audioManager.setStreamVolume(AUDIO_STREAM_TYPE, maxSteamVolume, AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
		} catch (Exception e) {
			RDDLog.error(Category.CAT_OTHER, "CustomAudioPlayer: _setVolumeToMax: Exception->" + e.getMessage());
			e.printStackTrace();
		}
	}

	private void _resetVolume() {
		_audioManager.setStreamVolume(AUDIO_STREAM_TYPE, _previsousVolume, AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
	}
}
