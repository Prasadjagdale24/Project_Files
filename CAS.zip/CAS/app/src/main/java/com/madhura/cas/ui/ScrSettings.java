package com.madhura.cas.ui;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import com.madhura.cas.R;
import com.madhura.cas.ui.controller.SettingsController;
import com.madhura.cas.utilities.DialogHelper;
import com.madhura.cas.utilities.SharedPreferenceManager;


/**
 * @author SAYYAD
 */
public class ScrSettings extends Activity {
    private SettingsController _controller;
    private TextView _tvCurrentSpeedLimit;

    private final int MIN_SPEED_LIMIT_VALUE = 30;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);

        _controller = new SettingsController(this);

        _setTitle();

        EditText etPhoneNumber = (EditText) findViewById(R.id.et_phone_number);
        etPhoneNumber.setText(SharedPreferenceManager.getInstance().getPhoneNumber());

        SeekBar sbMaxSpeedLimit = (SeekBar) findViewById(R.id.sb_speed_limit);
        int currentSpeedLimit = SharedPreferenceManager.getInstance().getMaxSpeedLimit();
        sbMaxSpeedLimit.setProgress((int) ((currentSpeedLimit / 1.2) - MIN_SPEED_LIMIT_VALUE));
        sbMaxSpeedLimit.setOnSeekBarChangeListener(_controller);

        _tvCurrentSpeedLimit = (TextView) findViewById(R.id.tv_current_speed_limit);
        _tvCurrentSpeedLimit.setText("" + currentSpeedLimit);

        Button btnSave = (Button) findViewById(R.id.btn_save);
        btnSave.setOnClickListener(_controller);

        _initBottomBar();
    }

    /**
     * Method to set the title
     */
    private void _setTitle() {
        TextView tvTitle = (TextView) findViewById(R.id.tv_title);
        tvTitle.setText(R.string.title_settings);
    }

    private void _initBottomBar() {
        Button btnAppointments = (Button) findViewById(R.id.btn_home);
        btnAppointments.setOnClickListener(_controller);

        Button btnAlerts = (Button) findViewById(R.id.btn_alerts);
        btnAlerts.setOnClickListener(_controller);

        Button btnSettings = (Button) findViewById(R.id.btn_settings);
        btnSettings.setSelected(true);
    }

    public void setCurrentSpeedLimit(int progress) {
        int currentSpeedLimit = (int) (MIN_SPEED_LIMIT_VALUE + (progress * 1.2));
        _tvCurrentSpeedLimit.setText("" + currentSpeedLimit);
    }

    public void saveSettings() {
        EditText etPhoneNumber = (EditText) findViewById(R.id.et_phone_number);
        String phoneNumber = etPhoneNumber.getText().toString();

        SeekBar sbMaxSpeedLimit = (SeekBar) findViewById(R.id.sb_speed_limit);
        int progress = sbMaxSpeedLimit.getProgress();

        int currentSpeedLimit = (int) (MIN_SPEED_LIMIT_VALUE + (progress * 1.2));
        _tvCurrentSpeedLimit.setText("" + currentSpeedLimit);

        SharedPreferenceManager.getInstance().setPhoneNumber(phoneNumber);
        SharedPreferenceManager.getInstance().setMaxSpeedLimit(currentSpeedLimit);
    }

    public boolean validateFields() {
        EditText etPhoneNumber = (EditText) findViewById(R.id.et_phone_number);
        Editable phoneNumber = etPhoneNumber.getText();
        if (TextUtils.isEmpty(phoneNumber)) {
            DialogHelper.showDialog(this, R.string.dlg_title_error, R.string.err_enter_phone_number, R.string.dlg_btn_ok, -1, -1, _dialogBtnClickListener);
            return false;
        }
        return true;
    }

    private OnClickListener _dialogBtnClickListener = new OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
        }
    };

    public void startHomeScreen() {
        Intent homeIntent = new Intent(ScrSettings.this, ScrMain.class);
        homeIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(homeIntent);
        this.finish();
    }

    public void startAlertsListScreen() {
        Intent alertsIntent = new Intent(ScrSettings.this, ScrAlertsList.class);
        alertsIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(alertsIntent);
        this.finish();
    }
}
