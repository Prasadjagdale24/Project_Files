package com.madhura.cas.utilities;

import android.content.Context;
import android.os.Environment;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.madhura.cas.MainApplication;


/**
 * Utility class to get different device parameters.
 * 
 */
public class DeviceUtils {

	/**
	 * Method to check if SD card is present
	 * 
	 * @return true if SD card is present, false otherwise
	 */
	public static boolean isSdCardPresent() {
		String state = Environment.getExternalStorageState();
		if (Environment.MEDIA_MOUNTED.equals(state) || Environment.MEDIA_SHARED.equals(state)) {
			return true;
		}
		return false;
	}

	/**
	 * Method to check if the sim card is present.
	 * 
	 * @return true if the sim card is present, false otherwise
	 */
	public static boolean isSimPresent() {
		TelephonyManager tm = (TelephonyManager) MainApplication.appContext.getSystemService(Context.TELEPHONY_SERVICE);
		if (tm != null) {
			if (!TextUtils.isEmpty(tm.getSimSerialNumber())) {
				return true;
			}
		}
		return false;
	}

	public static String getDatabaseDirectory(String dbName) {
		String path = null;
		path = MainApplication.appContext.getDatabasePath(dbName).getAbsolutePath();
		return path;
	}
}
