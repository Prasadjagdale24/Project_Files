package com.madhura.cas.ui;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.madhura.cas.Core;
import com.madhura.cas.LocationMonitor;
import com.madhura.cas.R;
import com.madhura.cas.logger.Category;
import com.madhura.cas.logger.RDDLog;
import com.madhura.cas.model.DrivingData;
import com.madhura.cas.ui.controller.MainController;
import com.madhura.cas.utilities.ChartUtility;
import com.madhura.cas.utilities.DialogHelper;


public class ScrMain extends Activity {
    private MainController _controller;
    private TextView _tvCurrentSpeed;
    private TextView _tvMaxSpeed;
    private TextView _tvAvgSpeed;
    private TextView _tvDistance;
    private TextView _tvAccelerationX;
    private TextView _tvAccelerationY;
    private TextView _tvAccelerationZ;


    ChartUtility chartObj;

    private Thread thread;
    private LineChart mchartAccelX, mchartAccelY, mchartAccelZ;
    private float  Accel_upperXThreshold = 2f, Accel_lowerXThreshold = -2f;

    private float  Accel_upperZThreshold = 3.5f, Accel_lowerZThreshold = -3.5f;

    private float  Gyro_upperYThreshold = 0.2f, Gyro_lowerYThreshold = -0.2f;

    private float  Fusion_Threshold = 0.3f;
    private float  Accel_upperYThreshold = 0.3f, Accel_lowerYThreshold = -0.3f;

    private final int START_GPS_REQUEST_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        RDDLog.debug(Category.CAT_GUI, "ScrMain: onCreate");

        _controller = new MainController(this);

        _setTitle();

        _tvCurrentSpeed = (TextView) findViewById(R.id.tv_current_speed);
        _tvMaxSpeed = (TextView) findViewById(R.id.tv_max_speed);
        _tvAvgSpeed = (TextView) findViewById(R.id.tv_avg_speed);
        _tvDistance = (TextView) findViewById(R.id.tv_distance);
        _tvAccelerationX = (TextView) findViewById(R.id.tv_acceleration_x);
        _tvAccelerationY = (TextView) findViewById(R.id.tv_acceleration_y);
        _tvAccelerationZ = (TextView) findViewById(R.id.tv_acceleration_z);
        _tvDistance = (TextView) findViewById(R.id.tv_distance);

        setRating();

        RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        ratingBar.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });

        _initBottomBar();
        try {
        LineChart chartAccelX = (LineChart) findViewById(R.id.chartAccelx);
        LineChart chartAccelY = (LineChart) findViewById(R.id.chartAccely);
        LineChart chartAccelZ = (LineChart) findViewById(R.id.chartAccelz);


            chartObj = new ChartUtility();
            mchartAccelX = chartObj.CreateChart(chartAccelX, Accel_upperXThreshold, Accel_lowerXThreshold, "Upper Limit X", "Lower Limit X", 5f, -5f);
            mchartAccelY = chartObj.CreateChart(chartAccelY, Accel_upperYThreshold, Accel_lowerYThreshold, "Upper Limit Y", "Lower Limit Y", 1f, -1f);
            mchartAccelZ = chartObj.CreateChart(chartAccelZ, Accel_upperZThreshold, Accel_lowerZThreshold, "Upper Limit Z", "Lower Limit Z", 5f, -5f);
            //feedMultiple();
        }catch (Exception e)
        {
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
    private void feedMultiple() {
        if (thread != null){
            thread.interrupt();
        }
        thread = new Thread(new Runnable() {

            @Override
            public void run() {
                while (true){
                    boolean plotData = true;
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        });
        thread.start();
    }

    @Override
    protected void onResume() {
        boolean isGpsEnabled = LocationMonitor.getInstance().isGpsEnabled();
        RDDLog.debug(Category.CAT_GUI, "ScrMain: onResume: isGpEnabled->" + isGpsEnabled);
        if (isGpsEnabled) {
            _controller.registerListener();
            _controller.startTracking();
        } else {
            Intent settingsIntent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivityForResult(settingsIntent, START_GPS_REQUEST_CODE);
        }
        super.onResume();
    }

    /**
     * Method to set the title
     */
    private void _setTitle() {
        TextView tvTitle = (TextView) findViewById(R.id.tv_title);
        tvTitle.setText(R.string.title_home);
    }

    private void _initBottomBar() {
        Button btnHome = (Button) findViewById(R.id.btn_home);
        btnHome.setSelected(true);

        Button btnAlerts = (Button) findViewById(R.id.btn_alerts);
        btnAlerts.setOnClickListener(_controller);

        Button btnSettings = (Button) findViewById(R.id.btn_settings);
        btnSettings.setOnClickListener(_controller);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void updateSpeed() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                DrivingData drivingData = DrivingData.getInstance();
                String currentSpeed = String.format(getString(R.string.lbl_speed_value), drivingData.getSpeed() * 3.6);
                String maxSpeed = String.format(getString(R.string.lbl_speed_value), drivingData.getMaxSpeed() * 3.6);
                String avgSpeed = String.format(getString(R.string.lbl_speed_value), drivingData.getAvgSpeed() * 3.6);

                _tvCurrentSpeed.setText(currentSpeed);
                _tvMaxSpeed.setText(maxSpeed);
                _tvAvgSpeed.setText(avgSpeed);

            }
        });
    }

    public void updateAceleration() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                DrivingData drivingData = DrivingData.getInstance();
                String accelerationX = String.format(getString(R.string.lbl_acceleration_x), drivingData.getAccelerationX());
                String accelerationY = String.format(getString(R.string.lbl_acceleration_y), drivingData.getAccelerationY());
                String accelerationZ = String.format(getString(R.string.lbl_acceleration_z), drivingData.getAccelerationZ());

                _tvAccelerationX.setText(accelerationX);
                _tvAccelerationY.setText(accelerationY);
                _tvAccelerationZ.setText(accelerationZ);
                try {
                   // chartObj.PlotChart(Double.parseDouble("0.3"), mchartAccelX, "Accelerometer x");
                    chartObj.PlotChart(Float.parseFloat(accelerationY), mchartAccelY, "Accelerometer y");
                    chartObj.PlotChart(Float.parseFloat(accelerationZ), mchartAccelZ, "Accelerometer z");

                }catch (Exception e)
                {
                    Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                }


            }
        });
    }

    public void updateDistance() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                DrivingData drivingData = DrivingData.getInstance();
                double distance = drivingData.getDistance() / 1000;
                String strDistance = String.format(getString(R.string.lbl_distance_value), distance);
                _tvDistance.setText(strDistance);
            }
        });
    }

    public void setRating() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);
                int alertsCount = Core.getInstance().getAlertsCount();
                if (alertsCount == 0) {
                    ratingBar.setRating(5.0F);
                } else if (alertsCount <= 5) {
                    ratingBar.setRating(4.5F);
                } else if (alertsCount > 5 && alertsCount <= 10) {
                    ratingBar.setRating(4.0F);
                } else if (alertsCount > 10 && alertsCount <= 15) {
                    ratingBar.setRating(3.5F);
                } else if (alertsCount > 15 && alertsCount <= 20) {
                    ratingBar.setRating(3.0F);
                } else if (alertsCount > 20 && alertsCount <= 25) {
                    ratingBar.setRating(2.5F);
                } else if (alertsCount > 25 && alertsCount <= 30) {
                    ratingBar.setRating(2.0F);
                } else if (alertsCount > 30 && alertsCount <= 35) {
                    ratingBar.setRating(1.5F);
                } else if (alertsCount > 35 && alertsCount <= 40) {
                    ratingBar.setRating(1.0F);
                } else if (alertsCount > 40 && alertsCount <= 45) {
                    ratingBar.setRating(0.5F);
                } else {
                    ratingBar.setRating(0.0F);
                }
            }
        });
    }

    public void startAlertsListScreen() {
        Intent alertsIntent = new Intent(ScrMain.this, ScrAlertsList.class);
        alertsIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(alertsIntent);
        this.finish();
    }

    public void startSettingsScreen() {
        Intent settingsIntent = new Intent(ScrMain.this, ScrSettings.class);
        settingsIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(settingsIntent);
        this.finish();
    }

    @Override
    public void onBackPressed() {
        DialogHelper.showDialog(this, R.string.dlg_title_warning, R.string.msg_exit, R.string.dlg_btn_ok, R.string.dlg_btn_cancel, -1, _dialogBtnClickListener);
    }

    private OnClickListener _dialogBtnClickListener = new OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            switch (which) {
                case DialogInterface.BUTTON_NEGATIVE:
                    if (_controller != null) {
                        _controller.stopTracking();
                    }
                    finish();
                    break;
            }
        }
    };
}
