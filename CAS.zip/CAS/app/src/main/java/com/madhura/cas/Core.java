package com.madhura.cas;

import java.util.Timer;
import java.util.TimerTask;

import android.text.TextUtils;

import com.madhura.cas.logger.Category;
import com.madhura.cas.logger.RDDLog;
import com.madhura.cas.model.Alert;
import com.madhura.cas.model.DrivingData;
import com.madhura.cas.model.SmsData;
import com.madhura.cas.notification.EventNotifier;
import com.madhura.cas.notification.EventTypes;
import com.madhura.cas.notification.IEventListener;
import com.madhura.cas.notification.ListenerPriority;
import com.madhura.cas.notification.NotifierFactory;
import com.madhura.cas.storage.Alerts;
import com.madhura.cas.utilities.CustomAudioPlayer;
import com.madhura.cas.utilities.DateTimeUtils;
import com.madhura.cas.utilities.SharedPreferenceManager;
import com.madhura.cas.utilities.SmsUtils;


public class Core implements IEventListener {
    private static Core _instance;

    private Timer _updateSpeedTimer;
    private UpdateSpeedTimerTask _updateSpeedTimerTask;
    private long UPDATE_SPEED_TIMEOUT = 1000;

    private Timer _updateAccelerationTimer;
    private UpdateAccelerationTask _updateAccelerationTask;
    private final long UPDATE_ACCELERATION_TIMER = 1000;

    private Timer _updatedDistanceTimer;
    private UpdateDistanceTask _updatedDistanceTask;
    private final long UPDATE_DISTANCE_TIMER = 5000;

    private long _startTime;
    private long _lastTime;

    private double _previousX;
    private double _previousY;

    private double _prevAcclX;
    private double _prevAcclY;
    private double _prevAcclZ;

    private final double ACCELERATION_THRESHOLD = 25.0000;

    private final int EARTH_RADIUS = 6371;

    /**
     * Timeout between subsequent over speeding alerts
     */
    private final long OVER_SPEEDING_ALERTS_TIMEOUT = 1 * 60 * 1000;

    /**
     * Timeout between subsequent alerts
     */
    private final long FALSE_DIRVING_ALERTS_TIMEOUT = 10 * 1000;

    private int _alertsCount;

    private Core() {

    }

    public static Core getInstance() {
        if (_instance == null) {
            _instance = new Core();
        }
        return _instance;
    }

    public void registerListener() {
        EventNotifier notifier = NotifierFactory.getInstance().getNotifier(NotifierFactory.LOCATION_EVENT_NOTIFIER);
        notifier.registerListener(_instance, ListenerPriority.PRIORITY_HIGH);
    }

    public void unregisterListener() {
        EventNotifier notifier = NotifierFactory.getInstance().getNotifier(NotifierFactory.LOCATION_EVENT_NOTIFIER);
        notifier.registerListener(_instance, ListenerPriority.PRIORITY_HIGH);
    }

    public void start() {
        registerListener();
        AccelerationMonitor.getInstance().start();
        LocationMonitor.getInstance().start();
        _startSpeedAndAcceletionTimer();
        _startDistanceTimer();
        _startUpdateTimer();
    }

    public void stop() {
        unregisterListener();
        LocationMonitor.getInstance().stop();
        AccelerationMonitor.getInstance().stop();
        _stopUpdateTimer();
        _stopSpeedAndAcceletionTimer();
        _stopDistanceTimer();
        _startTime = 0;
        _lastTime = 0;
        _previousX = 0;
        _previousY = 0;
        _alertsCount = 0;
    }

    public int getAlertsCount() {
        return _alertsCount;
    }

    // @Override
    // public void parametersUpdated() {
    // float accelationSquareRoot = (x * x + y * y + z * z) /
    // (SensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH);
    //
    // float longitudinalAcceleration = (float) Math.sqrt((x * x) + (y *
    // y));
    //
    // float alpha = (float) Math.acos(x /
    // (Math.abs(longitudinalAcceleration)));
    // float beta = (float) Math.acos(y /
    // (Math.abs(longitudinalAcceleration)));
    //
    // float Alat = (float) (x * Math.sin(alpha) + (y * Math.sin(beta)));
    // float Alon = (float) (x * Math.cos(alpha) + (y * Math.cos(beta)));
    // }

    private void _startUpdateTimer() {
        RDDLog.debug(Category.CAT_CONTROLLER, "Core: _startUpdateTimer");
        _updateSpeedTimer = new Timer();
        _updateSpeedTimerTask = new UpdateSpeedTimerTask();
        _updateSpeedTimer.schedule(_updateSpeedTimerTask, UPDATE_SPEED_TIMEOUT, UPDATE_SPEED_TIMEOUT);
    }

    private void _stopUpdateTimer() {
        RDDLog.debug(Category.CAT_CONTROLLER, "Core: _stopUpdateTimer");
        if (_updateSpeedTimerTask != null) {
            _updateSpeedTimerTask.cancel();
            _updateSpeedTimerTask = null;
        }

        if (_updateSpeedTimer != null) {
            _updateSpeedTimer.cancel();
            _updateSpeedTimer = null;
        }
    }

    private void _startSpeedAndAcceletionTimer() {
        RDDLog.debug(Category.CAT_CONTROLLER, "Core: _startSpeedAndAcceletionTimer");
        _stopSpeedAndAcceletionTimer();

        _updateAccelerationTimer = new Timer();
        _updateAccelerationTask = new UpdateAccelerationTask();
        _updateAccelerationTimer.schedule(_updateAccelerationTask, UPDATE_ACCELERATION_TIMER, UPDATE_ACCELERATION_TIMER);
    }

    private void _stopSpeedAndAcceletionTimer() {
        RDDLog.debug(Category.CAT_CONTROLLER, "Core: _stopSpeedAndAcceletionTimer");
        if (_updateAccelerationTask != null) {
            _updateAccelerationTask.cancel();
            _updateAccelerationTask = null;
        }

        if (_updateAccelerationTimer != null) {
            _updateAccelerationTimer.cancel();
            _updateAccelerationTimer = null;
        }
    }

    private void _startDistanceTimer() {
        RDDLog.debug(Category.CAT_CONTROLLER, "Core: _startDistanceTimer");
        _stopDistanceTimer();
        _updatedDistanceTimer = new Timer();
        _updatedDistanceTask = new UpdateDistanceTask();
        _updatedDistanceTimer.schedule(_updatedDistanceTask, 0, UPDATE_DISTANCE_TIMER);
    }

    private void _stopDistanceTimer() {
        RDDLog.debug(Category.CAT_CONTROLLER, "Core: _stopDistanceTimer");
        if (_updatedDistanceTask != null) {
            _updatedDistanceTask.cancel();
            _updatedDistanceTask = null;
        }

        if (_updatedDistanceTimer != null) {
            _updatedDistanceTimer.cancel();
            _updatedDistanceTimer = null;
        }
    }

    private class UpdateSpeedTimerTask extends TimerTask {
        @Override
        public void run() {
            DrivingData drivingData = DrivingData.getInstance();
            double maxSpeed = drivingData.getMaxSpeed();
            double currentSpeed = drivingData.getSpeed();
            double maxSpeedLimit = SharedPreferenceManager.getInstance().getMaxSpeedLimit();
            RDDLog.debug(Category.CAT_CONTROLLER, "Core: UpdateSpeedTimerTask: run: maxSpeed->" + maxSpeed + " currentSpeed->" + currentSpeed + " maxSpeedLimit->" + maxSpeedLimit);
            if (currentSpeed > maxSpeedLimit) {
                RDDLog.debug(Category.CAT_CONTROLLER, "Core: UpdateSpeedTimerTask: run: over speeding");
                if (!CustomAudioPlayer.getInstance().isPlaying()) {
                    CustomAudioPlayer.getInstance().play("alert.mp3", true);
                }

                long lastAlertTimestamp = SharedPreferenceManager.getInstance().getLastOverSpeedingAlertTimestamp();
                long currentTimestamp = System.currentTimeMillis();
                if (currentTimestamp - lastAlertTimestamp > OVER_SPEEDING_ALERTS_TIMEOUT) {
                    _alertsCount++;
                    RDDLog.debug(Category.CAT_CONTROLLER, "Core: UpdateSpeedTimerTask: run: difference->" + (currentTimestamp - lastAlertTimestamp) + " this is new alert");
                    SharedPreferenceManager.getInstance().setLastOverSpeedingAlertTimestamp(currentTimestamp);
                    String alertType = MainApplication.appContext.getString(R.string.over_speeding);
                    Alert alert = new Alert(currentTimestamp, alertType, (float) currentSpeed, drivingData.getLatitude(), drivingData.getLongitude());
                    Alerts.getInstance().add(alert);

                    String phoneNumber = SharedPreferenceManager.getInstance().getPhoneNumber();
                    if (!TextUtils.isEmpty(phoneNumber)) {
                        String strCurrentSpeed = String.format(MainApplication.appContext.getString(R.string.lbl_speed_value), drivingData.getSpeed() * 3.6);
                        String alertTimestamp = DateTimeUtils.getFormattedTime(currentTimestamp, DateTimeUtils.ALERT_TIME_STAMP_FORMAT);
                        String smsContent = String.format(MainApplication.appContext.getString(R.string.sms_content), alertType, alertTimestamp, strCurrentSpeed,
                                "" + (float) drivingData.getLatitude(), "" + (float) drivingData.getLongitude());

                        SmsData smsData = new SmsData("", phoneNumber, smsContent, 0, alertTimestamp);
                        new SmsUtils().sendSMS(smsData);
                    }
                }
            } else {
                if (CustomAudioPlayer.getInstance().isPlaying()) {
                    CustomAudioPlayer.getInstance().stop();
                }
            }

            if (currentSpeed > maxSpeed) {
                maxSpeed = currentSpeed;
                drivingData.setMaxSpeed(maxSpeed);
            }

            EventNotifier notifier = NotifierFactory.getInstance().getNotifier(NotifierFactory.SPEED_EVENT_NOTIFIER);
            notifier.eventNotify(EventTypes.EVENT_SPEED_CHANGED, DrivingData.getInstance());
        }
    }

    private class UpdateAccelerationTask extends TimerTask {
        @Override
        public void run() {
            RDDLog.debug(Category.CAT_CONTROLLER, "Core: UpdateAccelerationTask: run");
            EventNotifier notifier = NotifierFactory.getInstance().getNotifier(NotifierFactory.ACCELERATION_EVENT_NOTIFIER);
            notifier.eventNotify(EventTypes.EVENT_ACCELERATION_CHANGED, DrivingData.getInstance());

            double currentAcclX = DrivingData.getInstance().getAccelerationX();
            double currentAcclY = DrivingData.getInstance().getAccelerationY();
            double currentAcclZ = DrivingData.getInstance().getAccelerationZ();

            if (_prevAcclX == 0) {
                _prevAcclX = DrivingData.getInstance().getAccelerationX();
            }
            if (_prevAcclY == 0) {
                _prevAcclY = DrivingData.getInstance().getAccelerationY();
            }
            if (_prevAcclZ == 0) {
                _prevAcclZ = DrivingData.getInstance().getAccelerationZ();
            }

            String alertType = null;
            if (Math.abs(currentAcclX - _prevAcclX) > ACCELERATION_THRESHOLD) {
                if (currentAcclX > 0 && _prevAcclX > 0) {
                    if (currentAcclX > _prevAcclX) {
                        /**
                         * Turn right
                         */
                        alertType = MainApplication.appContext.getString(R.string.sudden_right);
                    } else {
                        /**
                         * Turn left
                         */
                        alertType = MainApplication.appContext.getString(R.string.sudden_left);
                    }
                } else if (currentAcclX < 0 && _prevAcclX < 0) {
                    if (currentAcclX > _prevAcclX) {
                        /**
                         * Turn right
                         */
                        alertType = MainApplication.appContext.getString(R.string.sudden_right);
                    } else {
                        /**
                         * Turn left
                         */
                        alertType = MainApplication.appContext.getString(R.string.sudden_left);
                    }
                } else if (currentAcclX > 0 && _prevAcclX < 0) {
                    /**
                     * Turn right
                     */
                    alertType = MainApplication.appContext.getString(R.string.sudden_right);
                } else if (currentAcclX < 0 && _prevAcclX > 0) {
                    /**
                     * Turn left
                     */
                    alertType = MainApplication.appContext.getString(R.string.sudden_left);
                }
            } else if (Math.abs(currentAcclY - _prevAcclY) > ACCELERATION_THRESHOLD) {
                /**
                 * Sudden break
                 */
                alertType = MainApplication.appContext.getString(R.string.sudden_brake);

            } else if (Math.abs(currentAcclZ - _prevAcclZ) > ACCELERATION_THRESHOLD) {
                if (currentAcclX > 0 && _prevAcclX > 0) {
                    if (currentAcclX > _prevAcclX) {
                        /**
                         * sudden acceleration
                         */
                        alertType = MainApplication.appContext.getString(R.string.sudden_acceleration);
                    } else {
                        /**
                         * acceleration
                         */
                        alertType = MainApplication.appContext.getString(R.string.acceleration);
                    }
                } else if (currentAcclX < 0 && _prevAcclX < 0) {
                    if (currentAcclX > _prevAcclX) {
                        /**
                         * sudden acceleration
                         */
                        alertType = MainApplication.appContext.getString(R.string.sudden_acceleration);
                    } else {
                        /**
                         * acceleration
                         */
                        alertType = MainApplication.appContext.getString(R.string.acceleration);
                    }
                } else if (currentAcclX > 0 && _prevAcclX < 0) {
                    /**
                     * sudden acceleration
                     */
                    alertType = MainApplication.appContext.getString(R.string.sudden_acceleration);
                } else if (currentAcclX < 0 && _prevAcclX > 0) {
                    /**
                     * acceleration
                     */
                    alertType = MainApplication.appContext.getString(R.string.acceleration);
                }
            }

            _prevAcclX = currentAcclX;
            _prevAcclY = currentAcclY;
            _prevAcclZ = currentAcclZ;

            DrivingData drivingData = DrivingData.getInstance();

            long lastAlertTimestamp = SharedPreferenceManager.getInstance().getLastFalseDrivingAlertTimestamp();
            long currentTimestamp = System.currentTimeMillis();
            if (!TextUtils.isEmpty(alertType) && currentTimestamp - lastAlertTimestamp > FALSE_DIRVING_ALERTS_TIMEOUT) {
                _alertsCount++;
                RDDLog.debug(Category.CAT_CONTROLLER, "Core: UpdateAccelerationTask: run: difference->" + (currentTimestamp - lastAlertTimestamp) + " this is new alert");
                SharedPreferenceManager.getInstance().setLastFalseDrivingAlertTimestamp(currentTimestamp);
                Alert alert = new Alert(currentTimestamp, alertType, (float) drivingData.getSpeed(), drivingData.getLatitude(), drivingData.getLongitude());
                Alerts.getInstance().add(alert);

                String phoneNumber = SharedPreferenceManager.getInstance().getPhoneNumber();
                if (!TextUtils.isEmpty(phoneNumber)) {
                    String strCurrentSpeed = String.format(MainApplication.appContext.getString(R.string.lbl_speed_value), drivingData.getSpeed() * 3.6);
                    String alertTimestamp = DateTimeUtils.getFormattedTime(currentTimestamp, DateTimeUtils.ALERT_TIME_STAMP_FORMAT);
                    String smsContent = String.format(MainApplication.appContext.getString(R.string.sms_content), alertType, alertTimestamp, strCurrentSpeed, "" + (float) drivingData.getLatitude(),
                            "" + (float) drivingData.getLongitude());

                    SmsData smsData = new SmsData("", phoneNumber, smsContent, 0, alertTimestamp);
                    new SmsUtils().sendSMS(smsData);
                }
            }
        }
    }

    private class UpdateDistanceTask extends TimerTask {
        @Override
        public void run() {
            DrivingData drivingData = DrivingData.getInstance();
            RDDLog.debug(Category.CAT_CONTROLLER, "Core: UpdateDistanceTask: run: _previousX->" + _previousX + " _previousY->" + _previousY);
            if (_previousX == 0 && _previousY == 0) {
                _previousX = drivingData.getLatitude();
                _previousY = drivingData.getLongitude();
                _startTime = System.currentTimeMillis();
                _lastTime = _startTime;

            } else {
                double currentX = drivingData.getLatitude();
                double currentY = drivingData.getLongitude();
                RDDLog.debug(Category.CAT_CONTROLLER, "Core: UpdateDistanceTask: run: currentX->" + currentX + " currentY->" + currentY);

                double distance = _getDistance(_previousX, _previousY, currentX, currentY);
                RDDLog.debug(Category.CAT_CONTROLLER, "Core: UpdateDistanceTask: run: distance->" + distance);
                drivingData.setDistance(drivingData.getDistance() + distance);

                double time = ((System.currentTimeMillis() - _lastTime) / 1000);
                if (time != 0) {
                    double currentSpeed = distance / time;
                    RDDLog.debug(Category.CAT_CONTROLLER, "Core: UpdateDistanceTask: run: currentSpeed->" + currentSpeed);
                    drivingData.setSpeed(currentSpeed);
                }

                time = ((System.currentTimeMillis() - _startTime) / 1000);
                if (time != 0) {
                    double avgSpeed = drivingData.getDistance() / time;
                    RDDLog.debug(Category.CAT_CONTROLLER, "Core: UpdateDistanceTask: run: avgSpeed->" + avgSpeed);
                    drivingData.setAvgSpeed(avgSpeed);
                }

                _lastTime = System.currentTimeMillis();

                _previousX = currentX;
                _previousY = currentY;
            }

            EventNotifier notifier = NotifierFactory.getInstance().getNotifier(NotifierFactory.DISTANCE_EVENT_NOTIFIER);
            notifier.eventNotify(EventTypes.EVENT_DISTANCE_CHANGED, drivingData);
        }
    }

    private double _getDistance(double startLat, double startLon, double endLat, double endLon) {
        double latA = Math.toRadians(startLat);
        double lonA = Math.toRadians(startLon);
        double latB = Math.toRadians(endLat);
        double lonB = Math.toRadians(endLon);
        double cosAng = (Math.cos(latA) * Math.cos(latB) * Math.cos(lonB - lonA)) + (Math.sin(latA) * Math.sin(latB));
        double ang = Math.acos(cosAng);
        double dist = ang * EARTH_RADIUS;
        return dist;
    }

    @Override
    public int eventNotify(int eventType, Object eventObject) {
        RDDLog.debug(Category.CAT_CONTROLLER, "Core: eventNotify: eventType->" + eventType);
        return 0;
    }
}
