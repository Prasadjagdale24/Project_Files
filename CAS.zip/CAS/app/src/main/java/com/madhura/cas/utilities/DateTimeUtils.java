package com.madhura.cas.utilities;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Utility class for handling date-time.
 * 
 */
public class DateTimeUtils {
	public static final String ALERT_TIME_STAMP_FORMAT = "yy/MM/dd HH:mm:ss";

	/**
	 * Method to get the current date-time in the input format.
	 * 
	 * @param dateTimeFormat
	 *            the date-time format
	 * @return the current date-time in the input format
	 */
	public static String getFormattedTime(String dateTimeFormat) {
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat, Locale.US);
		Date date = new Date(System.currentTimeMillis());
		return sdf.format(date);
	}

	/**
	 * Method to get the input date-time in the input format.
	 * 
	 * @param timeInMillis
	 *            the timestamp in milliseconds
	 * @param dateTimeFormat
	 *            the date-time format
	 * @return the current date-time in the input format
	 */
	public static String getFormattedTime(long timeInMillis, String dateTimeFormat) {
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat, Locale.US);
		Date date = new Date(timeInMillis);
		return sdf.format(date);
	}

	public static String getFormattedTime(String dateTimeFormat, Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat, Locale.US);
		return sdf.format(date);
	}
}
