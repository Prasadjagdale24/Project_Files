package com.madhura.cas.ui.controller;

import android.view.View;
import android.view.View.OnClickListener;

import com.madhura.cas.Core;
import com.madhura.cas.R;
import com.madhura.cas.logger.Category;
import com.madhura.cas.logger.RDDLog;
import com.madhura.cas.notification.EventNotifier;
import com.madhura.cas.notification.EventStates;
import com.madhura.cas.notification.EventTypes;
import com.madhura.cas.notification.IEventListener;
import com.madhura.cas.notification.ListenerPriority;
import com.madhura.cas.notification.NotifierFactory;
import com.madhura.cas.ui.ScrMain;


public class MainController implements OnClickListener, IEventListener {
    private ScrMain _screen;

    public MainController(ScrMain main) {
        _screen = main;
    }

    public void registerListener() {
        EventNotifier notifier = NotifierFactory.getInstance().getNotifier(NotifierFactory.LOCATION_EVENT_NOTIFIER);
        notifier.registerListener(MainController.this, ListenerPriority.PRIORITY_HIGH);

        notifier = NotifierFactory.getInstance().getNotifier(NotifierFactory.DISTANCE_EVENT_NOTIFIER);
        notifier.registerListener(MainController.this, ListenerPriority.PRIORITY_HIGH);

        notifier = NotifierFactory.getInstance().getNotifier(NotifierFactory.SPEED_EVENT_NOTIFIER);
        notifier.registerListener(MainController.this, ListenerPriority.PRIORITY_HIGH);

        notifier = NotifierFactory.getInstance().getNotifier(NotifierFactory.ACCELERATION_EVENT_NOTIFIER);
        notifier.registerListener(MainController.this, ListenerPriority.PRIORITY_HIGH);
    }

    public void startTracking() {
        RDDLog.debug(Category.CAT_CONTROLLER, "MainController: startTracking");
        Core.getInstance().start();
    }

    public void stopTracking() {
        RDDLog.debug(Category.CAT_CONTROLLER, "MainController: stopTracking");
        Core.getInstance().stop();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_settings:
                _screen.startSettingsScreen();
                break;

            case R.id.btn_alerts:
                _screen.startAlertsListScreen();
                break;
        }
    }

    @Override
    public int eventNotify(int eventType, Object eventObject) {
        int eventState = EventStates.STATE_IGNORED;
        switch (eventType) {
            case EventTypes.EVENT_DISTANCE_CHANGED:
                _screen.updateDistance();
                eventState = EventStates.STATE_PROCESSED;
                break;

            case EventTypes.EVENT_SPEED_CHANGED:
                _screen.updateSpeed();
                _screen.setRating();
                eventState = EventStates.STATE_PROCESSED;
                break;

            case EventTypes.EVENT_ACCELERATION_CHANGED:
                _screen.updateAceleration();
                eventState = EventStates.STATE_PROCESSED;
                break;
        }
        return eventState;
    }
}
