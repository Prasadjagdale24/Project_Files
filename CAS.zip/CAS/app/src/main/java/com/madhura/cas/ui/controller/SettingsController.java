package com.madhura.cas.ui.controller;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.madhura.cas.R;
import com.madhura.cas.ui.ScrSettings;


/**
 *
 */
public class SettingsController implements OnClickListener, OnSeekBarChangeListener {
    private ScrSettings _screen;

    /**
     * Parameterized Constructor
     *
     * @param settingsScreen the {@link ScrSettings} instance.
     */
    public SettingsController(ScrSettings settingsScreen) {
        _screen = settingsScreen;
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        int progress = seekBar.getProgress();
        _screen.setCurrentSpeedLimit(progress);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_save:
                if (_screen.validateFields()) {
                    _screen.saveSettings();
                }
                break;

            case R.id.btn_home:
                _screen.startHomeScreen();
                break;

            case R.id.btn_alerts:
                _screen.startAlertsListScreen();
                break;
        }
    }

}
