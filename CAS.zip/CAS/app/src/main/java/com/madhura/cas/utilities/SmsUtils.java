package com.madhura.cas.utilities;

import android.app.PendingIntent;
import android.content.Intent;
import android.telephony.PhoneNumberUtils;
import android.telephony.SmsManager;
import android.text.TextUtils;

import com.madhura.cas.MainApplication;
import com.madhura.cas.logger.Category;
import com.madhura.cas.logger.RDDLog;
import com.madhura.cas.model.SmsData;

import java.util.ArrayList;


public class SmsUtils {
    private static final String ACTION_SENT = "com.example.parentalcontrol.action_sms_sent";
    private static final String ACTION_DELIVERED = "com.example.parentalcontrol.action_sms_delivered";

    /**
     * Method to send sms.
     *
     * @param smsData the {@link SmsData} object containing phone number and content
     *                of sms to be sent
     */
    public void sendSMS(SmsData smsData) {
        String phoneNumber = smsData.getToAddess();
        String message = smsData.getSmsContent();
        RDDLog.debug(Category.CAT_OTHER, "SmsUtils: sendSms: phoneNumber->" + phoneNumber + " message->" + message);

        if (TextUtils.isEmpty(phoneNumber) || !PhoneNumberUtils.isGlobalPhoneNumber(phoneNumber)) {
            return;
        }
        /**
         * Register for SMS sent receiver
         */
        // MainApplication.appContext.registerReceiver(new SmsSentReceiver(),
        // new IntentFilter(ACTION_SENT));

        /**
         * Register for SMS delivered receiver
         */
        // MainApplication.appContext.registerReceiver(new
        // SmsDeliveredReceiver(), new IntentFilter(ACTION_DELIVERED));

        SmsManager sms = SmsManager.getDefault();
        /**
         * SMS character limit is 160 so break the sms before sending
         */
        ArrayList<String> messageParts = sms.divideMessage(message);

        /**
         * For every sms part register sent and delivered pending intents.
         */
        ArrayList<PendingIntent> sentPIs = new ArrayList<PendingIntent>();
        ArrayList<PendingIntent> deliveredPIs = new ArrayList<PendingIntent>();
        for (int i = 0; i < messageParts.size(); i++) {
            PendingIntent sentPI = PendingIntent.getBroadcast(MainApplication.appContext, 0, new Intent(ACTION_SENT), 0);
            PendingIntent deliveredPI = PendingIntent.getBroadcast(MainApplication.appContext, 0, new Intent(ACTION_DELIVERED), 0);

            sentPIs.add(sentPI);
            deliveredPIs.add(deliveredPI);
        }
        sms.sendMultipartTextMessage(phoneNumber, null, messageParts, sentPIs, deliveredPIs);
    }
}
