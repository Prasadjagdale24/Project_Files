package com.madhura.cas.model;

public class SmsData {
	private String fromAddress;
	private String toAddess;
	private String smsContent;
	private int smsType;
	private String timeStamp;

	public static final int SMS_TYPE_RECEIVED = 101;
	public static final int SMS_TYPE_SENT = 102;

	/**
	 * Parameterized Constructor
	 * 
	 * @param fromAddress
	 *            sender's phone number in case of incoming sms, null otherwise
	 * @param toAddress
	 *            recepient's phone number in case of outgoing sms, null
	 *            otherwise
	 * @param smsContent
	 *            the sms content
	 * @param smsType
	 *            the sms type(SMS_TYPE_RECEIVED/SMS_TYPE_SENT)
	 * @param timeStamp
	 *            the sent/received timestamp
	 */
	public SmsData(String fromAddress, String toAddress, String smsContent, int smsType, String timeStamp) {
		this.fromAddress = fromAddress;
		this.toAddess = toAddress;
		this.smsContent = smsContent;
		this.smsType = smsType;
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the fromAddress
	 */
	public String getFromAddress() {
		return fromAddress;
	}

	/**
	 * @param fromAddress
	 *            the fromAddress to set
	 */
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	/**
	 * @return the toAddess
	 */
	public String getToAddess() {
		return toAddess;
	}

	/**
	 * @param toAddess
	 *            the toAddess to set
	 */
	public void setToAddess(String toAddess) {
		this.toAddess = toAddess;
	}

	/**
	 * @return the smsContent
	 */
	public String getSmsContent() {
		return smsContent;
	}

	/**
	 * @param smsContent
	 *            the smsContent to set
	 */
	public void setSmsContent(String smsContent) {
		this.smsContent = smsContent;
	}

	/**
	 * @return the smsType
	 */
	public int getSmsType() {
		return smsType;
	}

	/**
	 * @param smsType
	 *            the smsType to set
	 */
	public void setSmsType(int smsType) {
		this.smsType = smsType;
	}

	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp
	 *            the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

}
