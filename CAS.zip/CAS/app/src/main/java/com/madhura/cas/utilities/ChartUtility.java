package com.madhura.cas.utilities;

import android.graphics.Color;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

public class ChartUtility {

  private LineChart mChart;

  public LineChart CreateChart(LineChart chart, float upperthreshold, float lowerthreshold, String  lblUpperThreshold, String  lblLowerThreshold, float chartDisplayUpperLimit, float chartDisplayLowerLimit)
  {

      mChart = chart;
      SetChartBasicSettings();

      //add empty data
      LineData data = new LineData();
      data.setValueTextColor(Color.WHITE);
      mChart.setData(data);

      SetChartDataSettings(chartDisplayUpperLimit,chartDisplayLowerLimit);

      SetChartLimits(upperthreshold, lowerthreshold, lblUpperThreshold,  lblLowerThreshold);

      return mChart;
  }

    public void PlotChart(float eventValue, LineChart chart, String chartDescription) {
        mChart = chart;

        LineData data = mChart.getData();

        if (data != null) {

            ILineDataSet set = data.getDataSetByIndex(0);
            // set.addEntry(...); // can be called as well

            if (set == null) {
                set = createSet(chartDescription);
                data.addDataSet(set);
            }

//            data.addEntry(new Entry(set.getEntryCount(), (float) (Math.random() * 80) + 10f), 0);
            data.addEntry(new Entry(set.getEntryCount(), eventValue ), 0);
            data.notifyDataChanged();

            // let the chart know it's data has changed
            mChart.notifyDataSetChanged();

            // limit the number of visible entries
            mChart.setVisibleXRangeMaximum(150);
            // mChart.setVisibleYRange(30, AxisDependency.LEFT);

            // move to the latest entry
            mChart.moveViewToX(data.getEntryCount());

        }
    }

    private LineDataSet createSet(String chartDescription) {
        LineDataSet set = new LineDataSet(null, chartDescription);
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setLineWidth(3f);
        set.setColor(Color.MAGENTA);
        set.setHighlightEnabled(false);
        //set.setDrawValues(false);
        set.setDrawCircles(false);
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set.setCubicIntensity(0.2f);
        set.setDrawValues(true);
        return set;
    }

    private void SetChartBasicSettings()
    {
        // enable touch gestures
        mChart.setTouchEnabled(true);
        // enable scaling and dragging
        mChart.setDragEnabled(true);
        mChart.setScaleEnabled(true);
        mChart.setDrawGridBackground(true);
        // if disabled, scaling can be done on x- and y-axis separately
        mChart.setPinchZoom(true);
        // set an alternative background color
        mChart.setBackgroundColor(Color.WHITE);

    }

    private void SetChartDataSettings(float chartDisplayUpperLimit, float chartDisplayLowerLimit)
    {
        // get the legend (only possible after setting data)
        Legend l = mChart.getLegend();
        // modify the legend ...
        l.setForm(Legend.LegendForm.LINE);
        l.setTextColor(Color.BLACK);
        XAxis xl = mChart.getXAxis();
        xl.setTextColor(Color.BLACK);
        xl.setDrawGridLines(true);
        xl.setAvoidFirstLastClipping(true);
        xl.setEnabled(true);

        YAxis leftAxis = mChart.getAxisLeft();
        leftAxis.setAxisMaximum(chartDisplayUpperLimit);
        leftAxis.setAxisMinimum(chartDisplayLowerLimit);
        leftAxis.setDrawAxisLine(true);

        //leftAxis.setGranularityEnabled(true);
        //leftAxis.setGranularity(1f);

        YAxis rightAxis = mChart.getAxisRight();
        rightAxis.setEnabled(false);

        mChart.getAxisLeft().setDrawGridLines(true);
        mChart.getXAxis().setDrawGridLines(true);
        mChart.getAxisRight().setDrawGridLines(true);
        mChart.setDrawBorders(true);

        mChart.getDescription().setEnabled(true);
        mChart.getDescription().setText("");
    }

    private void SetChartLimits(float upperthreshold, float lowerthreshold, String  lblUpperThreshold, String  lblLowerThreshold)
    {
        LimitLine upperlimit = new LimitLine(upperthreshold, lblUpperThreshold);
        upperlimit.setLineWidth(2f);
        upperlimit.enableDashedLine(2f, 10f, 0f);
        upperlimit.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_TOP);
        upperlimit.setTextSize(2f);

        LimitLine lowerlimit = new LimitLine(lowerthreshold, lblLowerThreshold);
        lowerlimit.setLineWidth(2f);
        lowerlimit.enableDashedLine(2f, 10f, 0f);
        lowerlimit.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_TOP);
        lowerlimit.setTextSize(2f);

        YAxis leftAxis = mChart.getAxisLeft();

        leftAxis.removeAllLimitLines(); // reset all limit lines to avoid overlapping lines
        leftAxis.addLimitLine(upperlimit);
        leftAxis.addLimitLine(lowerlimit);

    }

}
