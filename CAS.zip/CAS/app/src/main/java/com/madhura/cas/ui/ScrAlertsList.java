package com.madhura.cas.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.madhura.cas.R;
import com.madhura.cas.ui.controller.AlertsListController;


public class ScrAlertsList extends Activity {
    private AlertsListController _controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alerts_list);

        _controller = new AlertsListController(this);

        _setTitle();
        _initBottomBar();
    }

    private void _setTitle() {
        TextView tvTitle = (TextView) findViewById(R.id.tv_title);
        String title = String.format(getString(R.string.title_alerts), _controller.getCount());
        tvTitle.setText(title);
    }

    private void _initBottomBar() {
        Button btnAppointments = (Button) findViewById(R.id.btn_home);
        btnAppointments.setOnClickListener(_controller);

        Button btnAlerts = (Button) findViewById(R.id.btn_alerts);
        btnAlerts.setSelected(true);

        Button btnSettings = (Button) findViewById(R.id.btn_settings);
        btnSettings.setOnClickListener(_controller);
    }

    @Override
    protected void onResume() {
        ListView lvAppointmentList = (ListView) findViewById(R.id.lv_alerts);
        lvAppointmentList.setAdapter(_controller);
        lvAppointmentList.setOnItemClickListener(_controller);
        _setTitle();
        super.onResume();
    }

    public void startHomeScreen() {
        Intent homeIntent = new Intent(ScrAlertsList.this, ScrMain.class);
        homeIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(homeIntent);
        this.finish();
    }

    public void startSettingsScreen() {
        Intent settingsIntent = new Intent(ScrAlertsList.this, ScrSettings.class);
        settingsIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(settingsIntent);
        this.finish();
    }
}
