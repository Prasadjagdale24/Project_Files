package com.madhura.cas;

import java.lang.Thread.UncaughtExceptionHandler;

import android.app.Application;
import android.content.Context;

import com.madhura.cas.logger.Category;
import com.madhura.cas.logger.RDDLog;


/**
 * The main application class.
 */
public class MainApplication extends Application {
    public static Context appContext;

    @Override
    public void onCreate() {
        super.onCreate();
        appContext = this;

        // Alert alert = new Alert(System.currentTimeMillis(), 45.2F, 20.998630,
        // 75.566721);
        // Alerts.getInstance().add(alert);

        Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable ex) {
                RDDLog.error(Category.CAT_OTHER, "MainApplication: onCreate: uncaughtException->" + ex.getMessage());
                ex.printStackTrace();
                System.exit(1);
            }
        });
    }
}
