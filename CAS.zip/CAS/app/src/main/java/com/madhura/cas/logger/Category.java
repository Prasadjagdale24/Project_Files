package com.madhura.cas.logger;

public abstract class Category {
	public static final String CAT_GUI = "GUI";
	public static final String CAT_DATABASE = "DATABASE";
	public static final String CAT_CONTROLLER = "CONTROLLER";
	public static final String CAT_SERVICE = "SERVICE";
	public static final String CAT_RECEIVER = "RECEIVER";
	public static final String CAT_LOCATOR = "LOCATOR";
	public static final String CAT_OTHER = "OTHER";
}
