package com.madhura.cas;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.widget.Toast;

import com.madhura.cas.logger.Category;
import com.madhura.cas.logger.RDDLog;
import com.madhura.cas.model.DrivingData;


public class AccelerationMonitor implements SensorEventListener {
	private static AccelerationMonitor _instance;
	private SensorManager _sensorManager;
	private Sensor _sensor;

	/**
	 * Acceleration toward X-Axis
	 */
	private float prevX;
	/**
	 * Acceleration toward Y-Axis
	 */
	private float prevY;
	/**
	 * Acceleration toward Z-Axis
	 */
	private float prevZ;

	/**
	 * Longitudinal Acceleration
	 */
	private float Al;

	/**
	 * Angle between vector Axh and AI
	 */
	private float alpha;

	/**
	 * Angle between vector Ayh and AI.
	 */
	private float beta;

	/**
	 * Lateral acceleration
	 */
	private float Alat;

	/**
	 * Longitudinal acceleration
	 */
	private float Alon;

	private AccelerationMonitor() {

	}

	public static AccelerationMonitor getInstance() {
		if (_instance == null) {
			_instance = new AccelerationMonitor();
		}
		return _instance;
	}

	public void start() {
		try {
			_sensorManager = (SensorManager) MainApplication.appContext.getSystemService(Context.SENSOR_SERVICE);
			_sensor = _sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
			if (_sensor != null) {
				_sensorManager.registerListener(this, _sensor, SensorManager.SENSOR_DELAY_NORMAL);
				RDDLog.error(Category.CAT_RECEIVER, "AccelerationMonitor: start: Acceleration sensor initialized");

			} else {
				RDDLog.error(Category.CAT_RECEIVER, "Acceleration Sensor not found");
				Toast.makeText(MainApplication.appContext, "Acceleration Sensor not found", Toast.LENGTH_LONG).show();
			}
		} catch (Exception e) {
			RDDLog.error(Category.CAT_RECEIVER, "AccelerationMonitor: start: Exception->" + e.getMessage());
			e.printStackTrace();
		}
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
			float[] values = event.values;
			// Movement
			float x = values[0];
			float y = values[1];
			float z = values[2];

			DrivingData drivingData = DrivingData.getInstance();
			drivingData.setAccelerationX(x);
			drivingData.setAccelerationY(y);
			drivingData.setAccelerationZ(z);

			// EventNotifier notifier = NotifierFactory.getInstance()
		}
	}

	public void stop() {
		try {
			if (_sensor != null && _sensorManager != null) {
				_sensorManager.unregisterListener(_instance);
				_sensorManager = null;
				_sensor = null;
			}
		} catch (Exception e) {
			RDDLog.error(Category.CAT_RECEIVER, "AccelerationMonitor: stop: Exception->" + e.getMessage());
			e.printStackTrace();
		}
	}
}
