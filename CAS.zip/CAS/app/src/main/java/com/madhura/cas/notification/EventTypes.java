package com.madhura.cas.notification;

public class EventTypes {
	public static final int EVENT_LOCATION_CHANGED = 1;
	public static final int EVENT_DISTANCE_CHANGED = 2;
	public static final int EVENT_SPEED_CHANGED = 3;
	public static final int EVENT_ACCELERATION_CHANGED = 4;
}
