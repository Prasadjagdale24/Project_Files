package com.madhura.cas.notification;

public interface IEventListener {
	public int eventNotify(int eventType, Object eventObject);
}
