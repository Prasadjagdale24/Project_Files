package com.madhura.cas;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

import com.madhura.cas.logger.Category;
import com.madhura.cas.logger.RDDLog;
import com.madhura.cas.model.DrivingData;
import com.madhura.cas.notification.EventNotifier;
import com.madhura.cas.notification.EventTypes;
import com.madhura.cas.notification.NotifierFactory;


public class LocationMonitor {
	private static LocationMonitor _instance;
	private LocationManager _locationManager = null;
	private LocationListener _locationListener = null;

	/**
	 * Private Constructor
	 */
	private LocationMonitor() {

	}

	/**
	 * Method to get the initialized instance of {@link LocationMonitor}
	 * 
	 * @return the initialized instance of {@link LocationMonitor}
	 */
	public static LocationMonitor getInstance() {
		if (_instance == null) {
			_instance = new LocationMonitor();
			_instance._initializeLocationManager();
		}
		return _instance;
	}

	private void _initializeLocationManager() {
		if (_locationManager == null) {
			_locationManager = (LocationManager) MainApplication.appContext.getSystemService(Context.LOCATION_SERVICE);
		}
	}

	public void start() {

		_locationListener = new LocationListener();
		try {
			_locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, _locationListener);
		} catch (Exception e) {
			RDDLog.error(Category.CAT_LOCATOR, "LocationMonitor: start: Exception while initializing network provider->" + e.getMessage());
			e.printStackTrace();
		}

		try {
			_locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 100, _locationListener);
		} catch (Exception e) {
			RDDLog.error(Category.CAT_LOCATOR, "LocationMonitor: start: Exception while initializing GPS provider->" + e.getMessage());
			e.printStackTrace();
		}
	}

	private class LocationListener implements android.location.LocationListener {

		@Override
		public void onLocationChanged(Location location) {
			location.getAccuracy();
			double latitude = location.getLatitude();
			double longitude = location.getLongitude();
			double altitude = location.getAltitude();
			double speed = location.getSpeed();
			String provider = location.getProvider();

			RDDLog.debug(Category.CAT_LOCATOR, "LocationMonitor: onLocationChanged: latitude->" + latitude + " longitude->" + longitude + " altitude->" + altitude + " speed->" + speed + " provider->"
				+ provider);

			DrivingData data = DrivingData.getInstance();
			data.setLatitude(latitude);
			data.setLongitude(longitude);
			data.setAltitude(altitude);

			if (speed != Double.POSITIVE_INFINITY && speed != Double.NEGATIVE_INFINITY && speed != Double.NaN) {
				data.setSpeed(speed);
			}

			EventNotifier notifier = NotifierFactory.getInstance().getNotifier(NotifierFactory.LOCATION_EVENT_NOTIFIER);
			notifier.eventNotify(EventTypes.EVENT_LOCATION_CHANGED, location);
		}

		@Override
		public void onProviderDisabled(String provider) {

		}

		@Override
		public void onProviderEnabled(String provider) {

		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {

		}
	}

	/**
	 * Method to check if GPS/Network provider is enabled.
	 * 
	 * @return true if GPS/Network provider is enabled, false otherwise
	 */
	public boolean isGpsEnabled() {
		_initializeLocationManager();
		return _locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || _locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
	}

	public void stop() {
		try {
			if (_locationManager != null) {
				_locationManager.removeUpdates(_locationListener);
				_locationListener = null;
				_locationManager = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
