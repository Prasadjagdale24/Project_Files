package com.madhura.cas.ui.controller;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.madhura.cas.MainApplication;
import com.madhura.cas.R;
import com.madhura.cas.model.Alert;
import com.madhura.cas.storage.Alerts;
import com.madhura.cas.ui.ScrAlertsList;
import com.madhura.cas.utilities.DateTimeUtils;

import java.util.ArrayList;


public class AlertsListController extends BaseAdapter implements OnItemClickListener, OnClickListener {
    private final ScrAlertsList _screen;
    private ArrayList<Alert> _alertsList;
    private LayoutInflater _inflater;

    public AlertsListController(ScrAlertsList screen) {
        _screen = screen;
        _inflater = (LayoutInflater) _screen.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        _alertsList = Alerts.getInstance().getAllAlerts();
    }

    @Override
    public int getCount() {
        return _alertsList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = _inflater.inflate(R.layout.list_item, null);

        Alert alert = _alertsList.get(position);
        String alertType = alert.getAlertDescription();
        String alertTimestamp = DateTimeUtils.getFormattedTime(alert.getTimestamp(), DateTimeUtils.ALERT_TIME_STAMP_FORMAT);
        TextView tvAlertType = (TextView) convertView.findViewById(R.id.tv_heading);
        tvAlertType.setText(alertType + "\n" + alertTimestamp);

        String speed = String.format(MainApplication.appContext.getString(R.string.lbl_speed_value), alert.getCurrentSpeed());
        TextView tvSubheading = (TextView) convertView.findViewById(R.id.tv_subheading);
        tvSubheading.setText(speed);

        String location = String.format(MainApplication.appContext.getString(R.string.location_on_map), "" + alert.getLatitude(), "" + alert.getLongitude());
        TextView tvDescription = (TextView) convertView.findViewById(R.id.tv_description);
        tvDescription.setText(location);
        return convertView;
    }

    @Override
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_home:
                _screen.startHomeScreen();
                break;

            case R.id.btn_settings:
                _screen.startSettingsScreen();
                break;
        }
    }

}
