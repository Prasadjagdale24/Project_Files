package com.madhura.cas.storage;

import android.content.ContentValues;
import android.database.Cursor;

import com.madhura.cas.logger.Category;
import com.madhura.cas.logger.RDDLog;
import com.madhura.cas.model.Alert;
import com.madhura.cas.utilities.DateTimeUtils;

import java.util.ArrayList;

public class Alerts {
    private static Alerts _instance;
    private ArrayList<Alert> _alertsList = new ArrayList<Alert>();

    private final String TABLE_ALERTS = "Alerts";

    private final String COLUMN_ALERT_ID = "AlertId";
    private final String COLUMN_DESCRIPTION = "Description";
    private final String COLUMN_CURRENT_SPEED = "CurrentSpeed";
    private final String COLUMN_TIMESTAMP = "Timestamp";
    private final String COLUMN_LATITUDE = "Latitude";
    private final String COLUMN_LONGITUDE = "Longitude";

    private Alerts() {
    }

    public static Alerts getInstance() {
        if (_instance == null) {
            _instance = new Alerts();
        }
        return _instance;
    }

    public void add(Alert alert) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_DESCRIPTION, alert.getAlertDescription());
        values.put(COLUMN_CURRENT_SPEED, alert.getCurrentSpeed());
        values.put(COLUMN_TIMESTAMP, alert.getTimestamp());
        values.put(COLUMN_LATITUDE, alert.getLatitude());
        values.put(COLUMN_LONGITUDE, alert.getLongitude());

        MasterDatabase.getInstance().add(TABLE_ALERTS, null, values);
        _alertsList.add(0, alert);
    }

    public void remove(Alert alert) {

    }

    public ArrayList<Alert> getAllAlerts() {
        _alertsList = new ArrayList<Alert>();
        String[] columns = {COLUMN_ALERT_ID, COLUMN_DESCRIPTION, COLUMN_CURRENT_SPEED, COLUMN_TIMESTAMP, COLUMN_LATITUDE, COLUMN_LONGITUDE};
        String sortOrder = COLUMN_TIMESTAMP + " DESC";
        Cursor cursor = MasterDatabase.getInstance().getRecords(TABLE_ALERTS, columns, null, null, null, null, sortOrder);
        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                int alertId = cursor.getInt(0);
                String description = cursor.getString(1);
                float currentSpeed = cursor.getFloat(2);
                long timestamp = cursor.getLong(3);
                double latitude = cursor.getDouble(4);
                double longitude = cursor.getDouble(5);

                RDDLog.debug(
                        Category.CAT_DATABASE,
                        "Alerts: getAllAlerts: alertId->" + alertId + " description->" + description + " currentSpeed->" + currentSpeed + " timestamp->"
                                + DateTimeUtils.getFormattedTime(timestamp, DateTimeUtils.ALERT_TIME_STAMP_FORMAT) + " latitude->" + latitude + " longitude->" + longitude);
                Alert alert = new Alert(alertId, description, timestamp, currentSpeed, latitude, longitude);
                _alertsList.add(alert);
            }
        }
        return _alertsList;
    }
}
