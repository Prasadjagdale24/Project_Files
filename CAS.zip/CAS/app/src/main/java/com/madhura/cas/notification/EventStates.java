package com.madhura.cas.notification;

public class EventStates {
	public static final int STATE_IGNORED = 1;
	public static final int STATE_PROCESSED = 2;
	public static final int STATE_CONSUMED = 3;
}
