package com.madhura.cas.model;

public class Alert {
	private int alertId;
	private String alertDescription;
	private long timestamp;

	private float currentSpeed;
	private double latitude;
	private double longitude;

	/**
	 * Parameterized Constructor
	 * 
	 * @param alertId
	 *            the alertId
	 * @param description
	 *            the alert description
	 * @param timestamp
	 *            the timestamp i milliseconds when alert occurred
	 * @param currentSpeed
	 *            the speed at which alert was detected
	 * @param latitude
	 *            the latitude of location where alert was detected
	 * @param longitude
	 *            the longitude of location where alert was detected
	 */
	public Alert(int alertId, String description, long timestamp, float currentSpeed, double latitude, double longitude) {
		this.alertId = alertId;
		this.alertDescription = description;
		this.timestamp = timestamp;
		this.currentSpeed = currentSpeed;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	/**
	 * Parameterized Constructor
	 * 
	 * @param timestamp
	 *            the timestamp i milliseconds when alert occurred
	 * @param description
	 *            the alert description
	 * @param currentSpeed
	 *            the speed at which alert was detected
	 * @param latitude
	 *            the latitude of location where alert was detected
	 * @param longitude
	 *            the longitude of location where alert was detected
	 */
	public Alert(long timestamp, String description, float currentSpeed, double latitude, double longitude) {
		this.timestamp = timestamp;
		this.alertDescription = description;
		this.currentSpeed = currentSpeed;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	/**
	 * @return the alertId
	 */
	public int getAlertId() {
		return alertId;
	}

	/**
	 * @param alertId
	 *            the alertId to set
	 */
	public void setAlertId(int alertId) {
		this.alertId = alertId;
	}

	/**
	 * @return the alertDescription
	 */
	public String getAlertDescription() {
		return alertDescription;
	}

	/**
	 * @param alertDescription
	 *            the alertDescription to set
	 */
	public void setAlertDescription(String alertDescription) {
		this.alertDescription = alertDescription;
	}

	/**
	 * @return the timestamp
	 */
	public long getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp
	 *            the timestamp to set
	 */
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return the currentSpeed
	 */
	public float getCurrentSpeed() {
		return currentSpeed;
	}

	/**
	 * @param currentSpeed
	 *            the currentSpeed to set
	 */
	public void setCurrentSpeed(float currentSpeed) {
		this.currentSpeed = currentSpeed;
	}

	/**
	 * @return the latitude
	 */
	public double getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude
	 *            the latitude to set
	 */
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public double getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude
	 *            the longitude to set
	 */
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
}
