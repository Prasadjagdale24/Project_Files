package com.madhura.cas.utilities;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;

import com.madhura.cas.MainApplication;

/**
 * This is a singleton class used to save application settings to
 * {@link SharedPreferences}.
 * 
 */
public class SharedPreferenceManager {
	private static SharedPreferenceManager _instance;

	private SharedPreferences _sharedPreferences;
	private Editor _sharedPrefEditor;

	private static final String SHARED_PREFERENCE_NAME = "RashDriving";

	private String KEY_MAX_SPEED_LIMIT = "MAX_SPEED_LIMIT";
	private String KEY_PHONE_NUMBER = "PHONE_NUMBER";
	private String KEY_LAST_OVER_SPEEDING_ALERT_TIMESTAMP = "LAST_OVER_SPEEDING_ALERT_TIMESTAMP";
	private String KEY_LAST_FALSE_DRIVING_ALERT_TIMESTAMP = "LAST_FALSE_DRIVING_ALERT_TIMESTAMP";

	private int _maxSpeedLimit = 0;
	private String _phoneNumber;
	private long _lastOverSpeedingAlertTimestamp;

	private long _lastFalseDrivingAlertTimestamp;

	/**
	 * Private Constructor
	 */
	private SharedPreferenceManager() {
	}

	/**
	 * Method to get the initialized instance of this class.
	 * 
	 * @return the initialized instance of this class
	 */
	public static SharedPreferenceManager getInstance() {
		if (_instance == null) {
			_instance = new SharedPreferenceManager();
		}
		return _instance;
	}

	/**
	 * Method to get the {@link SharedPreferences} object
	 * 
	 * @return the {@link SharedPreferences} object
	 */
	private SharedPreferences _getSharedPreferences() {
		if (_sharedPreferences == null) {
			_sharedPreferences = MainApplication.appContext.getSharedPreferences(SHARED_PREFERENCE_NAME, Context.MODE_PRIVATE);
		}
		return _sharedPreferences;
	}

	/**
	 * Method to get the {@link Editor} object
	 * 
	 * @return the {@link Editor} object
	 */
	private Editor _getEditor() {
		if (_sharedPrefEditor == null) {
			_sharedPrefEditor = _getSharedPreferences().edit();
		}
		return _sharedPrefEditor;
	}

	public int getMaxSpeedLimit() {
		if (_maxSpeedLimit == 0) {
			_maxSpeedLimit = _getSharedPreferences().getInt(KEY_MAX_SPEED_LIMIT, 30);
		}
		return _maxSpeedLimit;
	}

	/**
	 * Method to set the max speed limit.
	 * 
	 * @param maxLimit
	 *            the max speed limit
	 */
	public void setMaxSpeedLimit(int maxLimit) {
		_maxSpeedLimit = maxLimit;
		_getEditor().putInt(KEY_MAX_SPEED_LIMIT, _maxSpeedLimit).commit();
	}

	/**
	 * @return the _phoneNumber
	 */
	public String getPhoneNumber() {
		if (TextUtils.isEmpty(_phoneNumber)) {
			_phoneNumber = _getSharedPreferences().getString(KEY_PHONE_NUMBER, null);
		}
		return _phoneNumber;
	}

	/**
	 * @param _phoneNumber
	 *            the _phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this._phoneNumber = phoneNumber;
		_getEditor().putString(KEY_PHONE_NUMBER, _phoneNumber).commit();
	}

	/**
	 * @return the _lastOverSpeedingAlertTimestamp
	 */
	public long getLastOverSpeedingAlertTimestamp() {
		_lastOverSpeedingAlertTimestamp = _getSharedPreferences().getLong(KEY_LAST_OVER_SPEEDING_ALERT_TIMESTAMP, 0);
		return _lastOverSpeedingAlertTimestamp;
	}

	/**
	 * @param lastAlertTimestamp
	 *            the _lastOverSpeedingAlertTimestamp to set
	 */
	public void setLastOverSpeedingAlertTimestamp(long lastAlertTimestamp) {
		this._lastOverSpeedingAlertTimestamp = lastAlertTimestamp;
		_getEditor().putLong(KEY_LAST_OVER_SPEEDING_ALERT_TIMESTAMP, lastAlertTimestamp).commit();
	}

	/**
	 * @return the _lastFalseDrivingAlertTimestamp
	 */
	public long getLastFalseDrivingAlertTimestamp() {
		_lastFalseDrivingAlertTimestamp = _getSharedPreferences().getLong(KEY_LAST_FALSE_DRIVING_ALERT_TIMESTAMP, 0);
		return _lastFalseDrivingAlertTimestamp;
	}

	/**
	 * @param lastFalseDrivingAlertTimestamp
	 *            the _lastFalseDrivingAlertTimestamp to set
	 */
	public void setLastFalseDrivingAlertTimestamp(long lastFalseDrivingAlertTimestamp) {
		this._lastFalseDrivingAlertTimestamp = lastFalseDrivingAlertTimestamp;
		_getEditor().putLong(KEY_LAST_FALSE_DRIVING_ALERT_TIMESTAMP, _lastFalseDrivingAlertTimestamp).commit();
	}
}
