package com.madhura.cas.model;

public class DrivingData {
	private double latitude;
	private double longitude;
	private double altitude;

	private double speed;
	private double maxSpeed;
	private double avgSpeed;
	
	private double accelerationX;
	private double accelerationY;
	private double accelerationZ;

	private double distance;
	
	private static DrivingData _instance = null;

	private DrivingData() {

	}

	public static DrivingData getInstance() {
		if (_instance == null) {
			_instance = new DrivingData();
		}
		return _instance;
	}

	/**
	 * @return the latitude
	 */
	public double getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude
	 *            the latitude to set
	 */
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public double getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude
	 *            the longitude to set
	 */
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return the altitude
	 */
	public double getAltitude() {
		return altitude;
	}

	/**
	 * @param altitude
	 *            the altitude to set
	 */
	public void setAltitude(double altitude) {
		this.altitude = altitude;
	}

	/**
	 * @return the speed
	 */
	public double getSpeed() {
		return speed;
	}

	/**
	 * @param speed
	 *            the speed to set
	 */
	public void setSpeed(double speed) {
		this.speed = speed;
	}

	/**
	 * @return the accelerationX
	 */
	public double getAccelerationX() {
		return accelerationX;
	}

	/**
	 * @param accelerationX
	 *            the accelerationX to set
	 */
	public void setAccelerationX(double accelerationX) {
		this.accelerationX = accelerationX;
	}

	/**
	 * @return the accelerationY
	 */
	public double getAccelerationY() {
		return accelerationY;
	}

	/**
	 * @param accelerationY
	 *            the accelerationY to set
	 */
	public void setAccelerationY(double accelerationY) {
		this.accelerationY = accelerationY;
	}

	/**
	 * @return the accelerationZ
	 */
	public double getAccelerationZ() {
		return accelerationZ;
	}

	/**
	 * @param accelerationZ
	 *            the accelerationZ to set
	 */
	public void setAccelerationZ(double accelerationZ) {
		this.accelerationZ = accelerationZ;
	}

	/**
	 * @return the maxSpeed
	 */
	public double getMaxSpeed() {
		return maxSpeed;
	}

	/**
	 * @param maxSpeed the maxSpeed to set
	 */
	public void setMaxSpeed(double maxSpeed) {
		this.maxSpeed = maxSpeed;
	}

	/**
	 * @return the avgSpeed
	 */
	public double getAvgSpeed() {
		return avgSpeed;
	}

	/**
	 * @param avgSpeed the avgSpeed to set
	 */
	public void setAvgSpeed(double avgSpeed) {
		this.avgSpeed = avgSpeed;
	}

	/**
	 * @return the distance
	 */
	public double getDistance() {
		return distance;
	}

	/**
	 * @param distance the distance to set
	 */
	public void setDistance(double distance) {
		this.distance = distance;
	}
}
