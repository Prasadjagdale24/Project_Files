package flat.rentals.advpi;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.AsyncTask;

import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import dmax.dialog.SpotsDialog;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    int finalstr = 0;
    int lfagImageProcess = 0;
    Button sendData,selectImage;
    EditText ipadress, texttobesent;
    TextView imageName;
    String s1 = "";
    ImageView imageView;
    int flag = 0;
    String ip = "192.168.206.181";
    final static int MY_PERMISSIONS_REQUEST = 444;
    byte[] byteImage1 = null;
    private Bitmap in1=null;
    private String selectedImagePath=null;
    SpotsDialog progress2;
    @Override     protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sendData = findViewById(R.id.sendData);
        sendData.setOnClickListener(this);

        selectImage = findViewById(R.id.selectImage);
        selectImage.setOnClickListener(this);

        ipadress = findViewById(R.id.ipaddr);
        texttobesent = findViewById(R.id.texttobesent);
        imageView = findViewById(R.id.imageView);
        imageName = findViewById(R.id.imageName);

        permissions();
    }
    @Override public void onClick(View view) {
        if(view.getId()==R.id.sendData) {
            try {
                if (flag == 0) {
                    SendData sd = new SendData();
                    sd.execute("TextString_" + texttobesent.getText().toString());
                    finalstr = 1;
                } else {
                    if (s1.length() > 0) {
                        SendData sd = new SendData();
                        sd.execute(s1);
                        finalstr = 1;
                    }

                }
            }
            catch (Exception e)
            {
                
            }


        }
        if(view.getId()==R.id.selectImage)
        {
            flag = 1 ;
           select_image_from_memory();
        }
    }
    //****************************************Image From, Gallary************************************
    public static Bitmap getResizedBitmap(Bitmap bm, int newHeight, int newWidth) {
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        Matrix matrix = new Matrix();
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight);
        // RECREATE THE NEW BITMAP
        Bitmap resizedBitmap = Bitmap.createBitmap(bm, 0, 0, width, height,
                matrix, false);
        return resizedBitmap;
    }
    public String BitMapToString(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] b = baos.toByteArray();
        String temp = Base64.encodeToString(b, Base64.DEFAULT);
        return temp;
    }

    private void setmyimage1(ByteArrayOutputStream stream) {
        try
        {
            byteImage1=stream.toByteArray();
            in1= BitmapFactory.decodeByteArray(byteImage1, 0,byteImage1.length);

            imageName.setText("File Is Selected");
            imageName.setTextColor(Color.parseColor("#00FF00"));
            s1 = BitMapToString(getResizedBitmap(in1,100,100));
            imageView.setImageBitmap(getResizedBitmap(in1,100,100));
        }
        catch(Exception e){}
    }
    public void select_image_from_memory() {
        try {
            CropImage.activity()
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .start(this);
        }catch (Exception e){Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();}

    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try
        {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE)
            {

                if (resultCode == RESULT_OK)
                {
                    Uri uri = result.getUri();
                    selectedImagePath=uri.toString();
                    Bitmap photo = MediaStore.Images.Media.getBitmap(this.getContentResolver(),uri);
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    photo.compress(Bitmap.CompressFormat.JPEG, 85, stream);
                    setmyimage1(stream);

                }
            }
            else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE)
            {
                Exception error = result.getError();

            }
        }
        catch (Exception e){}
    }
//*************************************************************************************************

    public class SendData extends AsyncTask<String , Void ,String> {
        Socket s;
        PrintWriter printwriter;
        DataOutputStream ds;

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(finalstr==1)
            {
                finalstr = 0;
                sentToats();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            try {

                    s = new Socket(ipadress.getText().toString(),13538);
                    printwriter = new PrintWriter(s.getOutputStream());
                    printwriter.write("TextString_" + texttobesent.getText().toString());
                    printwriter.flush();
                    printwriter.close();
                    s.close();
                    List<String> results = new ArrayList<>();
                    int n = 500;
                    int length = s1.length();
                    for (int i = 0; i < length; i += n) {
                        results.add(s1.substring(i, Math.min(length, i + n)));
                    }
                    for (int i = 0; i < results.size(); i++) {

                        SendData sd = new SendData();
                        sd.execute(results.toArray()[i].toString());
                        s = new Socket(ipadress.getText().toString(),13538);
                        printwriter = new PrintWriter(s.getOutputStream());
                        printwriter.write(results.toArray()[i].toString());
                        printwriter.flush();
                        printwriter.close();
                        s.close();
                    }
                    s = new Socket(ipadress.getText().toString(),13538);
                    printwriter = new PrintWriter(s.getOutputStream());
                    printwriter.write("image");
                    printwriter.flush();
                    printwriter.close();
                    s.close();

                    flag = 0;
                    s1 = "";
                    texttobesent.setText("");
                    imageName.setText("No File Selected");
                    imageName.setTextColor(Color.parseColor("#FFFFFF"));


            }
            catch (Exception e)
            {

            }

            return  null;
        }

    }

    private void sentToats() {
        Toast.makeText(getApplicationContext(),"Sent",Toast.LENGTH_LONG).show();
    }


    public void permissions() {
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            } else {
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE
                        },
                        MY_PERMISSIONS_REQUEST);
            }
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {
                    Toast.makeText
                            (
                                    getApplicationContext(), "Please Allow All Permissions, To Add Friends And Their Details. " +
                                            "This Is Non-Internet Application!",
                                    Toast.LENGTH_LONG
                            ).show();
                }

                return;
            }
        }
    }
}