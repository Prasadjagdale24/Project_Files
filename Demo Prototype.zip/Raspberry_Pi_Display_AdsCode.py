from tkinter import *
from tkinter import messagebox
import urllib.request
import base64
import time
from threading import Thread

tkWindow = Tk()
tkWindow.geometry('400x150')
tkWindow.title('Ads Broadcast')

def getResponseCode(url):
    conn = urllib.request.urlopen(url)
    return conn.read()

def dothis():
    t1 = Thread(target=showMsg)
    t1.start()

def showMsg():
    while(1):
        a = getResponseCode("https://www.prasadjagdale.com/viewDetails.php")
        s = str(a)
        p = (s.split("b")[1])
        q = p.replace("'","")
        lbl["text"] = q
        time.sleep(2.5)
        

button = Button(tkWindow,
        text = 'Start Showing Ads',
        command = dothis)
button.pack()

lbl=Label(tkWindow, text="s", fg='red', font=("Helvetica", 16))
lbl.pack()

tkWindow.mainloop()
