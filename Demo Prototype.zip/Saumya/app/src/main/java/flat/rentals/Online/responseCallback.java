package flat.rentals.Online;


public interface responseCallback
{
    void VolleyResponse(String data);
}
