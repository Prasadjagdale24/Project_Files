package flat.rentals.Online;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Database {

    ArrayList<String> JsonOutPuts = new ArrayList<>();

    //-----------------------Insert Details-----------------------------------------
    public void addDetails_pios(final Context cont, final String link_url, final String[] valuesToBeAdded) {
        RequestQueue queue;
        try {

            queue = Volley.newRequestQueue(cont);
            StringRequest postRequest = new StringRequest(Request.Method.POST, link_url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            ((responseCallback)cont).VolleyResponse(response);
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Data", valuesToBeAdded[0]);
                    return params;
                }
            };
            queue.add(postRequest);
        } catch (Exception e) {

        }
    }
    public ArrayList<String> process_addDetailspiosJSON(String data) {
        try { JsonOutPuts.add(data);} catch (Exception e) { }
        return JsonOutPuts;
    }
    //-----------------------Delete Details-----------------------------------------

}
