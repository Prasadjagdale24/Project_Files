package flat.rentals.Online;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.valdesekamdem.library.mdtoast.MDToast;

import java.util.ArrayList;

import dmax.dialog.SpotsDialog;


public class test_pi_communication extends AppCompatActivity implements View.OnClickListener ,responseCallback{

    EditText nameText;
    Button loginBtn;
    private SpotsDialog progress;
    ArrayList<String> respose=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_test_pi_communication);


        nameText = findViewById(R.id.nameText);
        loginBtn = findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.loginBtn)
        {
            insertDetails();
        }

    }
    private void insertDetails() {
        try
        {
            String[] valuesToBeAdded = new String[1];
            valuesToBeAdded[0] = nameText.getText().toString();

            progress = new SpotsDialog(test_pi_communication.this,R.style.Custom);
            progress.setMessage("Loading...Please Wait");
            progress.show();
            new Database().
                    addDetails_pios(
                            this,
                            getString(getResources().getIdentifier("InsertDetails_pios", "string", getPackageName())),
                            valuesToBeAdded);
        } catch (Exception e) {progress.dismiss();}
    }
    @Override public void VolleyResponse(String data) {
        try
        {

                progress.dismiss();
                respose = new Database().process_addDetailspiosJSON(data);
                if (respose.toArray()[0].toString().contains("New record created successfully"))
                {
                    MDToast.makeText(getApplicationContext(),
                            "Data Sent",
                            MDToast.TYPE_SUCCESS, MDToast.LENGTH_LONG).show();
                   nameText.setText("");

                }
                else
                {
                    MDToast.makeText(getApplicationContext(),
                            "Something Went Wrong",
                            MDToast.TYPE_ERROR, MDToast.LENGTH_LONG).show();
                }

        }
        catch (Exception e) {progress.dismiss();}


    }

}